(module) pip
pip.main(['install','speechrecognition'])